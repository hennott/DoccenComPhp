// @D:Diese Datei beinhaltet die Anzeige der CampusMap
console.log('CampusAppMap.js v0.0.0');