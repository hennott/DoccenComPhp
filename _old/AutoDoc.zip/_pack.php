<?php

pack_CleanFile('index.php');
pack_CleanFile('grabber.php');
pack_CleanFile('composer.php');
pack_CleanFile('autodoc.php');
pack_CleanFile('lib.php');
pack_CleanFile('de.lang');
pack_CleanFile('en.lang');
pack_CleanFile('set.config');
pack_CleanFile('my.config');

function pack_CleanFile($FileName) {
	$File = file_get_contents($FileName);

	$File = preg_replace('!/\*.*?\*/!s', '', $File);
	//$File = preg_replace('/\n\s*\n/', "\n", $File);
	//Remove Multiline Comments
	$File = preg_replace('!^[ \t]*/\*.*?\*/[ \t]*[\r\n]!s', '', $File);
	//Removes single line '//' comments, treats blank characters
	$File = preg_replace('![ \t]*// .*[ \t]*[\r\n]!', '', $File);
	//Strip blank lines
	$File = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $File);

	//$File = preg_replace( "/\r|\n/", " ", $File);
	//$File = preg_replace( '/;$\n/', ";", $File);
	echo 'Erzeugt <b>'.$FileName.'</b><br />';
	file_put_contents('_pack\\'.$FileName, $File);
	file_put_contents('SourceS\\AutoDoc SelfDoc\\'.$FileName, $File);
}

?>