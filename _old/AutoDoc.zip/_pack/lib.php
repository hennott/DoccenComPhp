<?php
//@E:Still in development! Only for experimental use!;
//@A:Markus Hottenrott @ share2brain.com;
$GLOBALS['AppVersion']['Lib'] = 'v0.0.1 (2015-02-03)';
function ab5_CrawleDir($Abic) {
	//@F:ab5_CrawleDir;
	//@I:Array<br />[Path] (Pfad der durchsucht werden soll)<br />[Mode] file,all,dir<br />[Level]<br />[Index];
	$ActDir = $Abic['Path'];
	if (substr($ActDir, strlen($ActDir) - 1) == DIRECTORY_SEPARATOR) {
		$ActDir = substr($ActDir, 0, strlen($ActDir) - 1);
	}
	if (isset($Abic['Mode'])) {
		$Mod = $Abic['Mode'];
	} else {
		$Mod = 'file';
	}
	if (isset($Abic['Level'])) {
		$Level = $Abic['Level'];
	} else {
		$Level = '0';
	}
	if (isset($Abic['Index'])) {
		$Index = $Abic['Index'];
	} else {
		$Index = '';
	}
	//@c:2014-11-20:Added a utf8 support for directory names;
	$ActDir = utf8_decode($ActDir);
	if(is_dir($ActDir)) {
		$Handle = opendir($ActDir);
		while ($Item = readdir($Handle)) {
			if ($Item != "." && $Item != "..") {
				if (is_dir($ActDir . DIRECTORY_SEPARATOR . $Item)) {
					if ($Mod == "all" || $Mod == "dir") {
						$Index[] = $ActDir . DIRECTORY_SEPARATOR . $Item;
					}
					if($Level > 1 || $Level == 0) {
						$PathNew = $ActDir . DIRECTORY_SEPARATOR . $Item;
						$AbicNew = array('Path' => $PathNew, 'Mode' => $Mod, 'Index' => $Index);
						$Index = ab5_CrawleDir($AbicNew);
						if(isset($Index['Result'])) {
							$Index = $Index['Result'];
						} else {
							$Index = '';
						}
					}
				} else {
					if (($Mod == "file") || ($Mod == "all")) {
						$Index[] = $ActDir . DIRECTORY_SEPARATOR . $Item;
					}
				}
			}
		}
		closedir($Handle);
	}
	if($Index !== '') {
		$Abic['Result'] = $Index;
	}
	$Abic['Response'] = 'OK';
	//@O:Array<br />[Result] Array mit Index als Liste<br />[Response] OK;
	return $Abic;
}
?>