<?php
//@E:Still in development! Only for experimental use!;
//@A:Markus Hottenrott @ share2brain.com;

$GLOBALS['AppVersion']['AutoDoc'] = 'v0.0.13 (2015-02-03)';
require_once('lib.php');

//@c:2015-02-03:Voller Umbau auf neue Architektur bezüglich externer Quellen von Config und Übersetzung.;

//@V:SetCfg < set.config;
$GLOBALS['SetCfg'] = json_decode(file_get_contents('set.config'));

//@R:Ergebnis sollte responsive sein, auch wenn man technische Dokumentationen nicht auf dem Handy sinnvoll verwenden kann.;
//@R:Sprachsteuerung mit Sprachversionen;
//@R:Verfügbare Updates von AutoDoc anzeigen inkl. automatisches Update der Applikation;

$LangS = explode(',', $GLOBALS['SetCfg']->DOC_Lang);

//@M:Es werden alle Sprachen geladen, die als verfügbar konfiguriert wurden.;
//@M:Wenn eine Sprache konfigurierte wurde, jedoch keine Sprachdatei hinterlegt ist, wird alternativ englisch verwendet.;
foreach ($LangS as $LangCode) {
	if(is_file($LangCode.'.lang')) {
		$Locale[$LangCode] = json_decode(file_get_contents($LangCode.'.lang'));
	} else {
		$Locale[$LangCode] = json_decode(file_get_contents('en.lang'));
	}
}

//@m:Für besonders umfangreiche Projekte sollte die max_execution_time angepasst werden;
ini_set('max_execution_time', 1440);
date_default_timezone_set($GLOBALS['SetCfg']->SET_TimeZone);

//@m:ErrorReporting für PHP kann de/aktiviert werden.;
if($GLOBALS['SetCfg']->SET_ErrorReporting == true) {
	error_reporting(E_ALL);
	ini_set('display_errors', 1);
}

//@m:Festlegung einer Sprache oder setzen der Standardsprache;
//@V:LangCurrent<br />LangCurrentCode;
if(isset($_GET['L'])) { $GLOBALS['LangCurrent'] = $Locale[$_GET['L']]; $GLOBALS['LangCurrentCode'] = $_GET['L']; } else { $GLOBALS['LangCurrent'] = $Locale[$LangS[0]];	$GLOBALS['LangCurrentCode'] = $LangS[0]; }
//@m:Sind mehr als eine Sprache aktiv, wird MultiLang auf true gesetzt;
//@V:MultiLang: true/false;
if(count($LangS) > 1) {	$GLOBALS['MultiLang'] = true; } else { $GLOBALS['MultiLang'] = false; }
//@c:2014-11-17:Erweiterunf gür mehrere DocS;
//@D:Wenn mehrere Dokumentation in der gleichen Umgebung erstellt werden soll, was die Übersichtlichkeit steigern kann, so kann eine Unterordnerstruktur angelegt werden. In den Ordner "DocS" werden dann Ordner mit dem entsprechenden Projektnamen gelegt. In diese "Projektordner" werden dann die Ordner "DocSet" und "DocAdd", sowie die "index.html" gelegt.;
//@V:$GLOBALS['DocS'] beinhaltet alle Unterpfade von DocS<br />$GLOBALS['MultiDoc']: true/false;
if(is_dir('DocS')) {
	$GLOBALS['MultiDoc'] = true;
	$GLOBALS['DocS'] = ab5_CrawleDir(array('Path'=>'DocS','Mode'=>'dir','Level'=>'1'));
	$GLOBALS['DocS'] = $GLOBALS['DocS']['Result'];
} else {
	$GLOBALS['MultiDoc'] = false;
}
//@V:$GLOBALS['Doc'];
if(isset($_GET['Doc']) && $GLOBALS['MultiDoc']) { 
	$GLOBALS['Doc'] = str_replace(DIRECTORY_SEPARATOR.DIRECTORY_SEPARATOR, DIRECTORY_SEPARATOR, $_GET['Doc']);
	//@c:2015-02-03:Die doppelten Verzeichnistrenner werden nun herausgenommen;
} else { 
	$GLOBALS['Doc'] = ''; 
}
//@V:$GLOBALS['CountFiles']<br />$GLOBALS['CountChapters']<br />$GLOBALS['DocAddFileS'];
if(isset($_GET['V'])) {
	$DocSetFileS = ab5_CrawleDir(array('Path'=>$GLOBALS['Doc'].$GLOBALS['SetCfg']->PATH_DocSet));
	$DocAddFileS = ab5_CrawleDir(array('Path'=>$GLOBALS['Doc'].$GLOBALS['SetCfg']->PATH_DocAdd));
	if(isset($DocSetFileS['Result'])) {	$GLOBALS['CountSources'] = count($DocSetFileS['Result']); } else { $GLOBALS['CountSources'] = 0; }
	if(isset($DocAddFileS['Result'])) { $GLOBALS['CountChapters'] = count($DocAddFileS['Result']); } else { $GLOBALS['CountChapters'] = 0; }
	$GLOBALS['CountFiles'] = $GLOBALS['CountChapters'] + $GLOBALS['CountSources'];
	$GLOBALS['DocAddFileS'] = $DocAddFileS;
	$Result = '';
//@M:Es werden PHP, JS, CSS, HTML und sonstige Textdateien berücksichtigt.;
	if(isset($DocSetFileS['Result']) && count($DocSetFileS['Result']) > 0) {
		foreach ($DocSetFileS['Result'] as $File) {
			$tmp = explode(".", $File);
			$FileExt = strtoupper(end($tmp));	
			$tmp = explode(DIRECTORY_SEPARATOR, $File);
			$FileName = end($tmp);
			switch($FileExt) {
				/*case "PHP": 
				case "JS":
				case "CSS":			
				case "HTML":*/
				default:
				$Result[] = ParseTxt($File);
			}
		}
	}
}
//@c:2014-10-29:Erweitert um Sprachunterstützung;
//@m:Hier wird die grundlegende Vorlage geladen. Diese enthält JS-Funktionen, CSS-Definitionen und das DOM-Modell.;
$Templ = '<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"/></head><body style="border-width: 0px; padding: 0px; margin: 0px; font-family: Open Sans; background-color: #DDDDDD;">
<div class="wrapper" style="position: relative; width: 90%; max-width: 1200px; margin-left: auto; margin-right: auto;">
	<div class="left1" style="position: relative; float: left; left: 0px; width: 100px; background-color: #AAAAAA; height: 100%;">
		<div id="NavBar" style="padding: 5px;">{{NavBar}}</div>
	</div>
	<div class="left2" style="position: relative; float: left; left: 0px; width: 300px; background-color: #0096ff; height: 100%;">
		<div id="SideBar" style="padding: 5px;">{{SideBar}}</div>
	</div>
	<div class="left3" style="position: relative; float: left; left: 0px; width: calc(100% - 400px); min-width: 200px; background-color: #FFFFFF; height: 100%;">
		<div id="MainContent" style="">{{MainContent}}</div>
	</div>
</div>
<style>
	.Headline { display:block; font-variant: small-caps; color: #FFFFFF; font-size: 20pt; font-weight: light;} 
	.HeadlineS { display:block; font-variant: small-caps; color: #FFFFFF; font-size: 15pt; font-weight: light; } 
	.MenuLink { color: #FFFFFF; text-decoration: none; cursor: pointer; }
	.RefLink { text-decoration: none; cursor: pointer; }
	.MenuText { color: #FFFFFF; }
	.MainContent { display: none; }
	.HeadlineC { display:block; color: #0096ff; font-size: 20pt; font-weight: light; margin: 5px; }
	.HeadlineCF { display:block; color: #0096ff; font-size: 15pt; font-weight: light; margin: 5px; }
	.HeadlineCH1 { display:block; color: #0096ff; font-size: 15pt; font-weight: light; margin: 5px; }
	.HeadlineCH2 { display:block; color: #0096ff; font-size: 12pt; font-weight: light; margin: 5px; }
	.HeadlineCH3 { display:block; color: #0096ff; font-size: 11pt; font-weight: light; margin: 5px; }
	.SideBarContent { display: none; }
	.PartMemo { color: #888888;	}
	.PartA { color: #888888; }
	.PartMind {	padding-left: 5px; border-left: 5px solid #66bb66; color: #66BB66;	}
	.Sub { color: #66BB66; }
	.PartD { font-weight: normal; }
	.PartE { padding-left: 5px; border-left: 5px solid #FF0000; background-color: #EEEEEE; color: #FF0000; }
	.PartI { padding-left: 5px; border-left: 5px solid #B404AE; background-color: #EEEEEE; }
	.PartS { padding-left: 5px; border-left: 5px solid #66bb66; background-color: #EEEEEE; font-family: "Lucida Console","Monaco","Andale Mono",monospace; color: #66bb66; }
	.PartO { padding-left: 5px; border-left: 5px solid #DD8800; background-color: #EEEEEE; }
	.PartV { padding-left: 5px; border-left: 5px solid #01DFD7; background-color: #EEEEEE; }
	.PartR { padding-left: 5px; border-left: 5px solid #0096ff; background-color: #EEEEEE; }
					#SideBar { overflow-x: hidden; overflow-y: auto; height: calc( 100% - 10px ); }
					#NavBar {overflow-y: auto; height: calc( 100% - 10px ); }
					#MainContent { overflow-x: hidden; overflow-y: auto;  height: calc( 100% - 10px ); }
	body{ font-family: Open Sans; font-size: 10pt; }
	h1 { color: #0096ff; font-size: 20pt; font-weight: normal; margin: 5px; }
	h2 { color: #0096ff; font-size: 15pt; font-weight: normal; margin: 5px; }
	h3 { color: #0096ff; font-size: 11pt; font-weight: normal; margin: 5px; }
	th{ text-align: left; font-size: 10pt; padding-left: 5px;}
	td {border: 5px solid #FFFFFF; background-color: #EEEEEE; padding: 5px;vertical-align: top;}
	.ChLog { width: 100%; }
	.ChLog td { padding: 2px;border: none;font-size: 10pt;margin: 5px;}
	.Info { width: 100%; }
	.Info td  { padding: 2px;border: none;font-size: 10pt;margin: 5px; background: none; border-bottom: 1px dashed #DDDDDD;}
	p {margin: 5px 10px 5px 10px;}
</style>
</body></html>';
echo '<script>function HideByClass(e){var t=document.querySelectorAll("."+e),n=0,r=t.length;for(n;n<r;n++){t[n].style.display="none"}}function ShowByClass(e){var t=document.querySelectorAll("."+e),n=0,r=t.length;for(n;n<r;n++){t[n].style.display="block"}}function ShowById(e){document.getElementById(e).style.display="block"}function HideById(e){document.getElementById(e).style.display="none"} function ShowFunction(FunctionName) { } function ShowFile(FileName) { HideByClass(\'MainContent\');console.log(FileName);ShowById(FileName);return false } function ShowChapter(ChapterName) { }
</script>';
if(!isset($_GET['Doc']) && $GLOBALS['MultiDoc']) {
	$Templ = str_replace('{{NavBar}}', '<span class="Headline"><a href="/" class="MenuLink">'.$GLOBALS['LangCurrent']->Global->Start.'</a></span>', $Templ);
	$ViewMenu = '<span class="Headline">'.$Locale[$LangS[0]]->AutoDoc->DocSStartView.'</span>';
	foreach($GLOBALS['DocS'] as $Doc) {
		$Doc = substr($Doc, strpos($Doc,DIRECTORY_SEPARATOR)+1);
		$ViewMenu = $ViewMenu . '<br /><a href="?Doc='.'DocS'.DIRECTORY_SEPARATOR.utf8_encode($Doc).'" style="color: #FFFFFF; text-decoration: none; cursor: pointer;">'.utf8_encode($Doc).'</a><br />';
	}
	$Templ = str_replace('{{SideBar}}', $ViewMenu, $Templ);
	if(is_file('DocS/'.$GLOBALS['SetCfg']->DOC_StartPage)) {
		$StartContent = '<div class="MainContent" id="Chapter_'.str_replace(DIRECTORY_SEPARATOR, '_', $GLOBALS['SetCfg']->DOC_StartPage).'" style="display: block;"><div style="margin: 5px;">'.ParseAddContent('DocS/'.$GLOBALS['SetCfg']->DOC_StartPage).'</div></div>';
	} else {
		$StartContent = '<div class="MainContent" id="Chapter_'.str_replace(DIRECTORY_SEPARATOR, '_', $GLOBALS['SetCfg']->DOC_StartPage).'" style="display: block;">..</div>';
	}
	$Templ = str_replace('{{MainContent}}', $StartContent, $Templ);
	echo $Templ;
} elseif(!isset($_GET['V'])) {
	if($GLOBALS['MultiDoc']) { $Templ = str_replace('{{NavBar}}', '<a href="/" class="MenuLink"><span class="Headline MenuLink">'.$GLOBALS['LangCurrent']->AutoDoc->NaviToStart.'</span></a>', $Templ); }
	$ViewMenu = '<span class="Headline">'.$GLOBALS['LangCurrent']->AutoDoc->StartView.'</span>';
	foreach($LangS as $Lang) {
		$ViewMenu = $ViewMenu .'<br /><span class="HeadlineS">'.$GLOBALS['LangCurrent']->Global->Language.'</span><a href="?V=User&L='.$Lang.'&Doc='.$GLOBALS['Doc'].DIRECTORY_SEPARATOR.'" style="color: #FFFFFF; text-decoration: none; cursor: pointer;">'.$GLOBALS['LangCurrent']->AutoDoc->User.'</a><br /><a href="?V=Expert&L='.$Lang.'&Doc='.$GLOBALS['Doc'].DIRECTORY_SEPARATOR.'" style="color: #FFFFFF; text-decoration: none; cursor: pointer;">'.$GLOBALS['LangCurrent']->AutoDoc->Expert.'</a><br />';
	}
	$Templ = str_replace('{{SideBar}}', $ViewMenu, $Templ);
	$Templ = str_replace('{{NavBar}}', '', $Templ);
	// @c:2015-01-20:Fehlerhafte Auswertung der Start.html zwischen Single-/MultiDoc;
	if(is_file(utf8_decode($GLOBALS['Doc']).DIRECTORY_SEPARATOR.$GLOBALS['SetCfg']->DOC_StartPage)) {
		$StartContentInner = '<div style="margin: 5px;">'.ParseAddContent(utf8_decode($GLOBALS['Doc']).DIRECTORY_SEPARATOR.$GLOBALS['SetCfg']->DOC_StartPage).'</div>';
	} elseif(is_file(utf8_decode($GLOBALS['Doc']).$GLOBALS['SetCfg']->DOC_StartPage)) {
		$StartContentInner = '<div style="margin: 5px;">'.ParseAddContent(utf8_decode($GLOBALS['Doc']).$GLOBALS['SetCfg']->DOC_StartPage).'</div>';
	} else {
		$StartContentInner = '..';
	}

	$StartContent = '<div class="MainContent" id="Chapter_'.str_replace(DIRECTORY_SEPARATOR, '_', $GLOBALS['SetCfg']->DOC_StartPage).'" style="display: block;"></div>';
	$StartContent = '<div class="MainContent" id="Chapter_'.str_replace(DIRECTORY_SEPARATOR, '_', $GLOBALS['SetCfg']->DOC_StartPage).'" style="display: block;">'.$StartContentInner.'</div>';
	$Templ = str_replace('{{MainContent}}', $StartContent, $Templ);
	echo $Templ;
} else {
	$VisualComponentS = VisualDoc($Result);
	$Templ = str_replace('{{NavBar}}', $VisualComponentS['NavBar'], $Templ);
	$Templ = str_replace('{{SideBar}}', $VisualComponentS['SideBar'], $Templ);
	$Templ = str_replace('{{MainContent}}', $VisualComponentS['MainContent'], $Templ);
	echo $Templ;
}

function VisualDoc ($FullIndex) {
	//@F:VisualDoc;
	//@c:2015-02-03:Querverweise für Dateien und Funktionen wurden eingeführt;
	//@c:2015-02-05:Die StartPage wird über die neue Funktion "ParseAddContent" eingebunden;
	$GlobalChangeLogS = Array();
	$DocSetFileS = Array();
	$FunctionS = Array();
	$MainContent = '';
	$DocAddFileS = $GLOBALS['DocAddFileS'];
	if(count($FullIndex) > 0 && $FullIndex !== '') {
		foreach($FullIndex as $IndexDoc) {
			//@c:2015-02-03:Alle Dateiverweise werden per Key angesprochen;
			if(!isset($GLOBALS['FileKey'])) { $GLOBALS['FileKey'] = 0; }
			$GLOBALS['FileKey'] += 1;
			$GLOBALS['FileRef'][$IndexDoc['FilePath']] = $GLOBALS['FileKey'];
			$MainContentFunction = '';
			$MainContentFile = '';
			$ChangeLogS = Array();
			if(isset($IndexDoc['c']) && count($IndexDoc['c']) > 0){
				foreach($IndexDoc['c'] as $ThisLog) {
					$GlobalChangeLogS[] = $ThisLog;
					$ChangeLogS[] = $ThisLog;
				}
			}
			$CountFileInner = 0;
			$MainContentFile = $MainContentFile.'<div class="MainContent" id="File_'.$GLOBALS['FileKey'].'"><span class="HeadlineC">'.$IndexDoc['FileName'].'</span>';
			if(isset($IndexDoc['TextS'])) {
				foreach($IndexDoc['TextS'] as $Item) {
					if($GLOBALS['MultiLang']) {
						if(substr($Item,-8,4) == '::'.$GLOBALS['LangCurrentCode']) {
							$MainContentFile = str_replace('::'.$GLOBALS['LangCurrentCode'], '', $MainContentFile.$Item);
							$CountFileInner += 1;
						}
					} else {
						$MainContentFile = $MainContentFile.$Item;
						$CountFileInner += 1;					
					}
				}       
			}
			if(isset($IndexDoc['FunctionS'])) {
				sort($IndexDoc['FunctionS']);
				foreach($IndexDoc['FunctionS'] as $FunctionName) {
					if(!isset($GLOBALS['CountFunctions'])) { $GLOBALS['CountFunctions'] = 0; }
					if(!isset($GLOBALS['FunctionKey'])) { $GLOBALS['FunctionKey'] = 0; }
					$GLOBALS['CountFunctions'] += 1;
					$GLOBALS['FunctionKey'] += 1;
					$GLOBALS['FunctionRef'][$FunctionName] = $GLOBALS['FunctionKey'];
					$MainContentFunction = $MainContentFunction.'<div class="MainContent" id="Function_'.$GLOBALS['FunctionKey'].'"><span class="HeadlineC">'.$FunctionName.'</span>';
					if($FunctionName !== '') {
						$FuncLink = '<small><a href="#" class="RefLink" onclick="ShowFile(\'Function_'.$GLOBALS['FunctionRef'][$FunctionName].'\'); return false;">[+]</a></small>';
					} else {
						$FuncLink = '';
					}
					$MainContentFile = $MainContentFile.'<span class="HeadlineCF">'.$FunctionName.' '.$FuncLink.'</span>';
					if(isset($IndexDoc[$FunctionName]['TextS']) && count($IndexDoc[$FunctionName]['TextS']) > 0) {
						$CountFileInner += 1;
						$FunctionInFileS[] = array('Label'=>'<small>'.$IndexDoc['FileName'].'</small> - '.$FunctionName,'Link'=>$GLOBALS['FunctionKey']);
						$FunctionS[] = array('Label'=>$FunctionName,'Link'=>$GLOBALS['FunctionKey']);
						foreach($IndexDoc[$FunctionName]['TextS'] as $Item) {
							$CountFileInner += 1;
							$MainContentFile = $MainContentFile.$Item;
							$MainContentFunction = $MainContentFunction.$Item;
						}
					}
					if(isset($IndexDoc[$FunctionName]['c']) && count($IndexDoc[$FunctionName]['c']) > 0) {
						$FuncChangeLogS = '';
						foreach($IndexDoc[$FunctionName]['c'] as $ThisLog) {
							$GlobalChangeLogS[] = $ThisLog;
							$ChangeLogS[] = $ThisLog;
							$FuncChangeLogS[] = $ThisLog;
						}
						$MainContentFunction = $MainContentFunction.'<span class="HeadlineCH2">'.$GLOBALS['LangCurrent']->AutoDoc->ChangeLog.'</span>'.ChangeLog($FuncChangeLogS);
					}
					$MainContentFunction = $MainContentFunction.'<span class="HeadlineCH2">'.$GLOBALS['LangCurrent']->AutoDoc->Path.'</span><p>'.$IndexDoc['FileName'].' <a href="#" class="RefLink" onclick="ShowFile(\'File_'.$GLOBALS['FileKey'].'\'); return false;">[+]</a></p>';
					$MainContentFunction = $MainContentFunction.'</div>';
				}
			}
			if(count($ChangeLogS) > 0) {
				$MainContentFile = $MainContentFile.'<span class="HeadlineCF">'.$GLOBALS['LangCurrent']->AutoDoc->ChangeLog.'</span>'.ChangeLog($ChangeLogS);
			}
			if($CountFileInner > 0){
				$DocSetFileS[] = '<a href="#" onclick="HideByClass(\'MainContent\');ShowById(\'File_'.$GLOBALS['FileKey'].'\');return false" class="MenuLink">'.$IndexDoc['FileName'].'</a></small>';
			}
			$MainContentFile = $MainContentFile.'<span class="HeadlineCF">'.$GLOBALS['LangCurrent']->AutoDoc->Path.'</span><p>'.$IndexDoc['FileName'].'</p>';
			$MainContentFile = $MainContentFile.'</div>';
			$CountFileInnerS[$IndexDoc['FilePath']] = $CountFileInner;
			$MainContent = $MainContent.$MainContentFunction.$MainContentFile;
			if(isset($IndexDoc['Eglobal']) && count($IndexDoc['Eglobal']) > 0 && $IndexDoc['Eglobal'] !== '') {
				$GlobalErrorLogS[] = array('Loc'=>$IndexDoc['FileName'],'FilePath'=>$IndexDoc['FilePath'],'DataS'=>$IndexDoc['Eglobal']);
				if(!isset($GLOBALS['CountErrors'])) { $GLOBALS['CountErrors'] = 0; }
				$GLOBALS['CountErrors'] = $GLOBALS['CountErrors'] + count($IndexDoc['Eglobal']);
			}
			if(isset($IndexDoc['Rglobal']) && count($IndexDoc['Rglobal']) > 0 && $IndexDoc['Rglobal'] !== '') {
				$GlobalRequestLogS[] = array('Loc'=>$IndexDoc['FileName'],'FilePath'=>$IndexDoc['FilePath'],'DataS'=>$IndexDoc['Rglobal']);
				if(!isset($GLOBALS['CountRequests'])) { $GLOBALS['CountRequests'] = 0; }
				$GLOBALS['CountRequests'] = $GLOBALS['CountRequests'] + count($IndexDoc['Rglobal']);
			}
		}
	}
	$GLOBALS['CountChanges'] = count($GlobalChangeLogS);
	//@c:2015-02-03:Darstellung des Namens der Dokumentation auf der Startseite wurde geändert;
	$GLOBALS['DocName'] = explode(DIRECTORY_SEPARATOR, substr($GLOBALS['Doc'], 0,-1));
	$GLOBALS['DocName'] = end($GLOBALS['DocName']);
    $SideBar = '<div id="GlobalInfo" style="display: block;" class="SideBarContent" ><span class="Headline">..</span><br /><span class="MenuText">'.$GLOBALS['LangCurrent']->AutoDoc->DocName.':<br /><b>'.$GLOBALS['DocName'].'</b></span><br /><br /><span class="MenuText">'.$GLOBALS['LangCurrent']->AutoDoc->StartView.':<br /><b>'.$GLOBALS['LangCurrent']->AutoDoc->$_GET['V'].' ('.$GLOBALS['LangCurrent']->Global->Language.')</b></span></div>';
	$GlobalFileList = '<span class="Headline">'.$GLOBALS['LangCurrent']->AutoDoc->File.'</span>';
	foreach ($DocSetFileS as $FileLink) {
		$GlobalFileList = $GlobalFileList.$FileLink.'<br />';
	}
	$GlobalFileList = $GlobalFileList.'';
	$SideBar = $SideBar.'<div id="GlobalFileList" class="SideBarContent">'.$GlobalFileList.'</div>';
	if(isset($DocAddFileS['Result']) && count($DocAddFileS['Result']) > 0) {
		$GlobalChapterList = '<span class="Headline">'.$GLOBALS['LangCurrent']->AutoDoc->Chapter.'</span>';
		//@c:2015-02-03:Kapitel korrekt eingebunden. Eine Pfadangabe entfällt, da der Dateiname der Überschrift entspricht.;
		//@c:2015-02-03:Kapitel werden jetzt über eine ChapterId angesprochen.;
		if($GLOBALS['MultiLang']) {
			foreach ($DocAddFileS['Result'] as $FileLink) {
				if(!isset($GLOBALS['ChapterKey'])) { $GLOBALS['ChapterKey'] = 0; }
				$GLOBALS['ChapterKey'] += 1;
				$FileName = substr($FileLink, strrpos($FileLink, DIRECTORY_SEPARATOR)+1,strrpos($FileLink, '.') - strrpos($FileLink, DIRECTORY_SEPARATOR)-1);
				$GLOBALS['ChapterRef'][$FileName] = $GLOBALS['ChapterKey'];
				if(substr($FileName,-3) == '.'.$GLOBALS['LangCurrentCode']) {
					$FileName = substr($FileName,0,-3);
					$MainContent = $MainContent.'<div class="MainContent" id="Chapter_'.$GLOBALS['ChapterKey'].'"><span class="HeadlineC">'.$FileName.'</span><div style="margin: 5px;">'.file_get_contents($FileLink).'</div></div>';
					$FileLink = '<a href="#" onclick="HideByClass(\'MainContent\');ShowById(\'Chapter_'.$GLOBALS['ChapterKey'].'\');return false" class="MenuLink">'.$FileName.'</a>';
					$GlobalChapterList = $GlobalChapterList.$FileLink.'<br />';
				}
			}
			$GlobalChapterList = $GlobalChapterList.'</p>';
			$SideBar = $SideBar.'<div id="GlobalChapterList" class="SideBarContent">'.$GlobalChapterList.'</div>';
		} else {
			foreach ($DocAddFileS['Result'] as $FileLink) {
				if(!isset($GLOBALS['ChapterKey'])) { $GLOBALS['ChapterKey'] = 0; }
				$GLOBALS['ChapterKey'] += 1;
				$FileName = substr($FileLink, strrpos($FileLink, DIRECTORY_SEPARATOR)+1,strrpos($FileLink, '.') - strrpos($FileLink, DIRECTORY_SEPARATOR)-1);
				$GLOBALS['ChapterRef'][$FileName] = $GLOBALS['ChapterKey'];
				$MainContent = $MainContent.'<div class="MainContent" id="Chapter_'.$GLOBALS['ChapterKey'].'"><span class="HeadlineC">'.$FileName.'</span><div style="margin: 5px;">'.ParseAddContent($FileLink).'</div></div>';
				$FileLink = '<a href="#" onclick="HideByClass(\'MainContent\');ShowById(\'Chapter_'.$GLOBALS['ChapterKey'].'\');return false" class="MenuLink">'.$FileName.'</a>';
				$GlobalChapterList = $GlobalChapterList.$FileLink.'<br />';
			}
			$GlobalChapterList = $GlobalChapterList.'</p>';
			$SideBar = $SideBar.'<div id="GlobalChapterList" class="SideBarContent">'.$GlobalChapterList.'</div>';
		}
	}
	if(count($FunctionS) > 0) {
		$GlobalFunctionList = '<span class="Headline">'.$GLOBALS['LangCurrent']->AutoDoc->Function.'</span>';
		sort($FunctionS);
		foreach ($FunctionS as $FunctionName) {
			$GlobalFunctionList = $GlobalFunctionList.'<a href="#" onclick="HideByClass(\'MainContent\');ShowById(\'Function_'.$FunctionName['Link'].'\');return false" class="MenuLink">'.$FunctionName['Label'].'</a><br />';
		}
		$GlobalFunctionList = $GlobalFunctionList.'<br /><a href="#" onclick="HideByClass(\'MainContent\');HideByClass(\'SideBarContent\'); ShowById(\'GlobalFunctionListInFile\');return false" class="MenuLink"><small>['.$GLOBALS['LangCurrent']->AutoDoc->SortFuncByFile.']</small></a>';
		$SideBar = $SideBar.'<div id="GlobalFunctionList" class="SideBarContent">'.$GlobalFunctionList.'</div>';
		$GlobalFunctionListInFile = '<span class="Headline">'.$GLOBALS['LangCurrent']->AutoDoc->Function.'</span>';
		foreach ($FunctionInFileS as $FunctionName) {
			$GlobalFunctionListInFile = $GlobalFunctionListInFile.'<a href="#" onclick="HideByClass(\'MainContent\');ShowById(\'Function_'.$FunctionName['Link'].'\');return false" class="MenuLink">'.$FunctionName['Label'].'</a><br />';
		}
		$GlobalFunctionListInFile = $GlobalFunctionListInFile.'<br /><a href="#" onclick="HideByClass(\'MainContent\');HideByClass(\'SideBarContent\'); ShowById(\'GlobalFunctionList\');return false" class="MenuLink"><small>['.$GLOBALS['LangCurrent']->AutoDoc->SortFuncByName.']</small></a><br />';
		$SideBar = $SideBar.'<div id="GlobalFunctionListInFile" class="SideBarContent">'.$GlobalFunctionListInFile.'</div>';		
	}
	if(!isset($GlobalChangeLogS)) { $GlobalChangeLogS = ''; }
	$MainContent = $MainContent.'<div class="MainContent" id="GlobalChangeLog"><span class="HeadlineC">'.$GLOBALS['LangCurrent']->AutoDoc->ChangeLog.'</span>'.GlobalChangeLog($GlobalChangeLogS,'Date','SORT_DESC').'</div>';
	if(!isset($GlobalErrorLogS)) { $GlobalErrorLogS = ''; }
	$MainContent = $MainContent.'<div class="MainContent" id="GlobalErrorLog"><span class="HeadlineC">'.$GLOBALS['LangCurrent']->AutoDoc->ErrorLog.'</span>'.RenderLog($GlobalErrorLogS,'Loc','SORT_ASC').'</div>';
	if(!isset($GlobalRequestLogS)) { $GlobalRequestLogS = ''; }
	$MainContent = $MainContent.'<div class="MainContent" id="GlobalRequestLog"><span class="HeadlineC">'.$GLOBALS['LangCurrent']->AutoDoc->RequestLog.'</span>'.RenderLog($GlobalRequestLogS,'Loc','SORT_ASC').'</div>';
	$MainContent = $MainContent.'<div class="MainContent" id="RawIndex"><span class="HeadlineC">'.$GLOBALS['LangCurrent']->AutoDoc->RawIndex.'</span><p>'.ab5_ReturnArrayAsTree($FullIndex).'</p></div>';
	if(!isset($GLOBALS['CountFunctions'])) { $GLOBALS['CountFunctions'] = 0; }
	if(!isset($GLOBALS['CountErrors'])) { $GLOBALS['CountErrors'] = 0; }
	if(!isset($GLOBALS['CountRequests'])) { $GLOBALS['CountRequests'] = 0; }
	if(!isset($GLOBALS['CountChanges'])) { $GLOBALS['CountChanges'] = 0; }
	$SideBar = $SideBar.'<div id="ToolSideInfo" class="SideBarContent" style="color: #FFFFFF;"><span class="Headline">'.$GLOBALS['LangCurrent']->AutoDoc->AutoDocInfo.'</span>'.$GLOBALS['LangCurrent']->AutoDoc->FileCount.': '.$GLOBALS['CountSources'].' '.$GLOBALS['LangCurrent']->AutoDoc->CountOf.' '.$GLOBALS['CountFiles'].'<br />'.$GLOBALS['LangCurrent']->AutoDoc->FunctionCount.': '.$GLOBALS['CountFunctions'].'<br />'.$GLOBALS['LangCurrent']->AutoDoc->ChapterCount.': '.$GLOBALS['CountChapters'].'<br />'.$GLOBALS['LangCurrent']->AutoDoc->LogCount.': '.count($GlobalChangeLogS).'<br />'.$GLOBALS['LangCurrent']->AutoDoc->ErrorCount.': '.$GLOBALS['CountErrors'].'<br />'.$GLOBALS['LangCurrent']->AutoDoc->RequestCount.': '.$GLOBALS['CountRequests'].'<br />'.$GLOBALS['LangCurrent']->AutoDoc->DocReleaseDate.': '.date('Y-m-d',time()).'<br /><br /><a href="https://autodoc.share2brain.com" style="color: #FFFFFF; text-decoration: none;">'.$GLOBALS['LangCurrent']->AutoDoc->LinkToSelfDocu.'</a><br /><br />'.$GLOBALS['LangCurrent']->AutoDoc->LinkToHome.'<br /><a href="https://autodoc.share2brain.com" style="color: #FFFFFF; text-decoration: none;"><b>autodoc.share2brain.com</b></a><br /><br /><small>'.$GLOBALS['LangCurrent']->AutoDoc->Version.' AutoDoc: '.$GLOBALS['AppVersion']['AutoDoc'].'<br />'.$GLOBALS['LangCurrent']->AutoDoc->Version.' Lib: '.$GLOBALS['AppVersion']['Lib'].'<br />'.$GLOBALS['LangCurrent']->AutoDoc->Version.' Schema: '.$GLOBALS['SetCfg']->schemaversion.'<br /></small></div>';
	//@stop;
	$MainContent = $MainContent.'<div class="MainContent" id="ToolInfo"><span class="HeadlineC">AutoDoc</span><p>'.$GLOBALS['LangCurrent']->AutoDoc->BasicHelp->Info.'</p><p>
		<table class="Info">
			<tr><th></th><th>'.$GLOBALS['LangCurrent']->AutoDoc->Expert.'</th><th>'.$GLOBALS['LangCurrent']->AutoDoc->User.'</th></tr>
			<tr><td colspan="99"><br /><b>'.$GLOBALS['LangCurrent']->AutoDoc->BasicHelp->HeadlineCommentDirect.'</b></td></tr>
			<tr><td><span class="HeadlineCF"><b>@F</b> '.$GLOBALS['LangCurrent']->AutoDoc->Function.';</span></td><td>x</td><td>x</td></tr>
			<tr><td><span class="HeadlineCH2"><b>@H</b> '.$GLOBALS['LangCurrent']->AutoDoc->Headline.';</span></td><td>x</td><td>x</td></tr>
			<tr><td><span class="HeadlineCH1"><b>@H1</b> '.$GLOBALS['LangCurrent']->AutoDoc->Headline.';</span></td><td>x</td><td>x</td></tr>
			<tr><td><span class="HeadlineCH2"><b>@H2</b> '.$GLOBALS['LangCurrent']->AutoDoc->Headline.';</span></td><td>x</td><td>x</td></tr>
			<tr><td><span class="HeadlineCH3"><b>@H3</b> '.$GLOBALS['LangCurrent']->AutoDoc->Headline.';</span></td><td>x</td><td>x</td></tr>
			<tr><td><span class="PartA"><b>@A</b> '.$GLOBALS['LangCurrent']->AutoDoc->Author.';</span></td><td>x</td><td>-</td></tr>
			<tr><td><span class="PartD"><b>@D</b> Text;</span></td><td>x</td><td>x</td></tr>
			<tr><td><span class="PartMemo"><b>@M</b> Memo;</span></td><td>x</td><td>x</td></tr>
			<tr><td><span class="PartMind"><b>@m</b> ExpertsMemo;</span></td><td>x</td><td>-</td></tr>
			<tr><td><span class="PartS"><b>@S</b> SourceCode Sample;</span></td><td>x</td><td>x</td></tr>
			<tr><td><span class="PartI"><b>@I</b> Input;</span></td><td>x</td><td>-</td></tr>
			<tr><td><span class="PartV"><b>@V</b> Variablen;</span></td><td>x</td><td>-</td></tr>
			<tr><td><span class="PartO"><b>@O</b> Output;</span></td><td>x</td><td>-</td></tr>
			<tr><td><span class="PartR"><b>@R</b> '.$GLOBALS['LangCurrent']->AutoDoc->Request.';</span></td><td>x</td><td>-</td></tr>
			<tr><td><span class="PartE"><b>@E</b> '.$GLOBALS['LangCurrent']->AutoDoc->BasicHelp->KnownIssue.';</span></td><td>x</td><td>-</td></tr>
			<tr><td colspan="99"><br /><b>'.$GLOBALS['LangCurrent']->AutoDoc->BasicHelp->HeadlineCommentIndirect.'</b></td></tr>
			<tr><td><span class="PartC"><b>@c:2014-10-01:</b> ChangeLog;</span></td><td>x</td><td>-</td></tr>
			<tr><td colspan="99"><br /><b>'.$GLOBALS['LangCurrent']->AutoDoc->BasicHelp->HeadlineCommentHidden.'</b></td></tr>
			<tr><td colspan="99"><b>@stop;</b> '.$GLOBALS['LangCurrent']->AutoDoc->BasicHelp->ParseStop.'</td></tr>
			<tr><td colspan="99"><b>@start;</b> '.$GLOBALS['LangCurrent']->AutoDoc->BasicHelp->ParseStart.'</td></tr>
			<tr><td colspan="99"><b>de:</b> '.$GLOBALS['LangCurrent']->AutoDoc->BasicHelp->TranslateComment.';</td></tr>
			<tr><td colspan="99"><b>.de</b> '.$GLOBALS['LangCurrent']->AutoDoc->BasicHelp->TranslateFile.'</td></tr>
		</table></div>';
	//@start;
	//@c:2015-02-03:Der Button "Menü" führt zum Start von AutoDoc zurück und nicht zur obersten Einstiegsebene;
	$NavBar = '<span class="Headline"><a href="?" class="MenuLink">'.$GLOBALS['LangCurrent']->AutoDoc->Navi.'</a></span>';
	$NavBar = $NavBar.'<a href="" class="MenuLink">'.$GLOBALS['LangCurrent']->AutoDoc->Start.'</a><br />';
	if(isset($DocAddFileS['Result']) && count($DocAddFileS['Result']) > 0) {
		$NavBar = $NavBar.'<a href="#" onclick="HideByClass(\'SideBarContent\'); HideByClass(\'MainContent\'); ShowById(\'GlobalChapterList\'); return false;" class="MenuLink">'.$GLOBALS['LangCurrent']->AutoDoc->Chapter.'</a><br />';
	}
	if(isset($DocSetFileS) && count($DocSetFileS) > 0) {
		$NavBar = $NavBar.'<a href="#" onclick="HideByClass(\'SideBarContent\'); HideByClass(\'MainContent\'); ShowById(\'GlobalFileList\'); return false;" class="MenuLink">'.$GLOBALS['LangCurrent']->AutoDoc->File.'</a><br />';
	}
	if(isset($FunctionS) && count($FunctionS) > 0) {
		$NavBar = $NavBar.'<a href="#" onclick="HideByClass(\'SideBarContent\'); HideByClass(\'MainContent\'); ShowById(\'GlobalFunctionList\'); return false;" class="MenuLink">'.$GLOBALS['LangCurrent']->AutoDoc->Function.'</a><br />';
	}
	if($_GET['V']=='Expert') {
		$NavBar = $NavBar.'<br />';
		if(isset($GLOBALS['CountErrors']) && $GLOBALS['CountErrors'] > 0) {
			$NavBar = $NavBar.'<a href="#" onclick="HideByClass(\'SideBarContent\'); HideByClass(\'MainContent\'); ShowById(\'GlobalErrorLog\'); return false;" class="MenuLink">'.$GLOBALS['LangCurrent']->AutoDoc->ErrorLog.'</a><br />';
		}
		if(isset($GLOBALS['CountRequests']) && $GLOBALS['CountRequests'] > 0) {
			$NavBar = $NavBar.'<a href="#" onclick="HideByClass(\'SideBarContent\'); HideByClass(\'MainContent\'); ShowById(\'GlobalRequestLog\'); return false;" class="MenuLink">'.$GLOBALS['LangCurrent']->AutoDoc->RequestLog.'</a><br />';
		}
		if(isset($GLOBALS['CountChanges']) && $GLOBALS['CountChanges'] > 0) {
			$NavBar = $NavBar.'<a href="#" onclick="HideByClass(\'SideBarContent\'); HideByClass(\'MainContent\'); ShowById(\'GlobalChangeLog\'); return false;" class="MenuLink">'.$GLOBALS['LangCurrent']->AutoDoc->ChangeLog.'</a><br />';
		}
		$NavBar = $NavBar.'<a href="#" onclick="HideByClass(\'SideBarContent\'); HideByClass(\'MainContent\'); ShowById(\'RawIndex\'); return false;" class="MenuLink">'.$GLOBALS['LangCurrent']->AutoDoc->RawIndex.'</a><br />';
	    //@c:2014-10-16:Suchmodus hinzugefügt, der alles einblendet;
		$NavBar = $NavBar.'<a href="#" onclick="ShowByClass(\'SideBarContent\'); ShowByClass(\'MainContent\'); return false;" class="MenuLink">'.$GLOBALS['LangCurrent']->AutoDoc->SearchMode.'</a><br />';    
		$NavBar = $NavBar.'<br /><a href="#" onclick="HideByClass(\'SideBarContent\'); HideByClass(\'MainContent\'); ShowById(\'ToolSideInfo\'); ShowById(\'ToolInfo\'); return false;" class="MenuLink">'.$GLOBALS['LangCurrent']->AutoDoc->AutoDocInfo.'</a><br />';
	}
	if(is_file(utf8_decode($GLOBALS['Doc']).$GLOBALS['SetCfg']->DOC_StartPage)) {
		$MainContent = $MainContent.'<div class="MainContent" id="Chapter_'.str_replace(DIRECTORY_SEPARATOR, '_', $GLOBALS['SetCfg']->DOC_StartPage).'" style="display: block;"><div style="margin: 5px;">'.ParseAddContent(utf8_decode($GLOBALS['Doc']).$GLOBALS['SetCfg']->DOC_StartPage).'</div></div>';
	} else {
		$MainContent = $MainContent.'<div class="MainContent" id="Chapter_'.str_replace(DIRECTORY_SEPARATOR, '_', $GLOBALS['SetCfg']->DOC_StartPage).'" style="display: block;"></div>';
	}
	$VisualComponentS['NavBar'] = $NavBar;
	$VisualComponentS['SideBar'] = $SideBar;
	$VisualComponentS['MainContent'] = $MainContent;
	return $VisualComponentS;
}

function ParseAddContent ($FileLink) {
	//@F:ParseAddContent;
	//@D:Für eine verbesserte Einbindung von zusätzlichen Dokumenten (DocAdd), wandelt diese Funktion den importieren HTML-Code so um, dass am Ende ein funktionierendes Dokument eingebunden werden kann. Dies betrifft beispielsweise die Einbettung von Grafiken.;
	//@c:2015-02-05:Funktion wurde hinzugefügt.;
	$FileContent = file_get_contents($FileLink);
	$DocDom = new DOMDocument();
    $DocDom->loadHTML($FileContent);
	$TagS = $DocDom->getElementsByTagName('img');
	foreach ($TagS as $Tag) {
		$OldSrc = $Tag->getAttribute('src');
		$OldSrcExt = explode('.', $OldSrc);
		$OldSrcExt = strtolower(end($OldSrcExt));
		$FilePath = substr($FileLink,0,strrpos($FileLink, DIRECTORY_SEPARATOR));
		$NewSrc = 'data:image/'.$OldSrcExt.';base64,'.base64_encode(file_get_contents($FilePath.DIRECTORY_SEPARATOR.$OldSrc));
		$Tag->setAttribute('src', $NewSrc);
	}
	return $DocDom->saveHTML();
}

function ParseContent ($Doc,$File) {
	//@F:ParseContent;
	//@D:Diese Funktion baut den Index auf;
	//@c:2014-10-29:Changelog kann jetzt mit Datum 2014-10-01 oder mit Versionsnummer 0.0.1 definiert werden, bzw. mit allem, was zwischen den beiden Doppelpunkten steht;
	//@c:2014-10-29:Die Variablen I und O werden jetzt auch der Datei, statt nur einer Funktion zugeordnet;
	//@c:2014-10-21:Es können <br /> Tags zur Strukturierung von Code verwendet werden;
	//@stop;
	$PathS = explode(DIRECTORY_SEPARATOR,$File);
	$File = utf8_encode($File);
	$DocIndex['FilePath'] = $File;
	$DocIndex['FileName'] = end($PathS);
	$Parse = true;
	$i = 0;
	while($Parse == true) {
		$Pos = FindNext($Doc,array('@F:','@c:','@M:','@S','@H:','@H1:','@H2:','@H3:','@m:','@D:','@A:','@I:','@O:','@V:','@R:','@E:','@stop;'));
		if($Pos !== false) {
			$Doc = substr($Doc, $Pos);
			$Case = substr($Doc, 0, strpos($Doc, ':')+1);
			if(strlen($Case) > 5) {
				$Case = substr($Doc, 0, strpos($Doc, ';')+1);
			}
			switch($Case) {
				case '@F:':
				$EndPos = strpos($Doc, ';')+1;
				$DocI = substr($Doc, 0, $EndPos);
				$F = substr($DocI, 3, strpos($DocI, ';', 3)-3);
				if($F !== '') {
					$DocIndex['FunctionS'][] = $F;
				}
				break;
				case '@H:':
				$EndPos = strpos($Doc, ';')+1;
				$DocI = substr($Doc, 0, $EndPos);
				$H = substr($DocI, 3, strpos($DocI, ';', 3)-3);
				if(isset($F) && $F <> '') {
					$DocIndex[$F]['H'][] = str_replace(array('*', '//'),"<br />",$H);
					$DocIndex[$F]['TextS'][] = '<p class="HeadlineCH2">'.str_replace(array('*', '//'),"<br />",$H).'</p>';
				} else {
					$DocIndex['H'][] = str_replace(array('*', '//'),"<br />",$H);
					$DocIndex['TextS'][] = '<p class="HeadlineCH1">'.str_replace(array('*', '//'),"<br />",$H).'</p>';
				}
				break;
				case '@H1:':
				$EndPos = strpos($Doc, ';')+1;
				$DocI = substr($Doc, 0, $EndPos);
				$H = substr($DocI, 4, strpos($DocI, ';', 4)-4);
				if(isset($F) && $F <> '') {
					$DocIndex[$F]['H'][] = str_replace(array('*', '//'),"<br />",$H);
					$DocIndex[$F]['TextS'][] = '<p class="HeadlineCH1">'.str_replace(array('*', '//'),"<br />",$H).'</p>';
				} else {
					$DocIndex['H'][] = str_replace(array('*', '//'),"<br />",$H);
					$DocIndex['TextS'][] = '<p class="HeadlineCH1">'.str_replace(array('*', '//'),"<br />",$H).'</p>';
				}
				break;	
				case '@H2:':
				$EndPos = strpos($Doc, ';')+1;
				$DocI = substr($Doc, 0, $EndPos);
				$H = substr($DocI, 4, strpos($DocI, ';', 4)-4);
				if(isset($F) && $F <> '') {
					$DocIndex[$F]['H'][] = str_replace(array('*', '//'),"<br />",$H);
					$DocIndex[$F]['TextS'][] = '<p class="HeadlineCH2">'.str_replace(array('*', '//'),"<br />",$H).'</p>';
				} else {
					$DocIndex['H'][] = str_replace(array('*', '//'),"<br />",$H);
					$DocIndex['TextS'][] = '<p class="HeadlineCH2">'.str_replace(array('*', '//'),"<br />",$H).'</p>';
				}
				break;	
				case '@H3:':
				$EndPos = strpos($Doc, ';')+1;
				$DocI = substr($Doc, 0, $EndPos);
				$H = substr($DocI, 4, strpos($DocI, ';', 4)-4);
				if(isset($F) && $F <> '') {
					$DocIndex[$F]['H'][] = str_replace(array('*', '//'),"<br />",$H);
					$DocIndex[$F]['TextS'][] = '<p class="HeadlineCH3">'.str_replace(array('*', '//'),"<br />",$H).'</p>';
				} else {
					$DocIndex['H'][] = str_replace(array('*', '//'),"<br />",$H);
					$DocIndex['TextS'][] = '<p class="HeadlineCH3">'.str_replace(array('*', '//'),"<br />",$H).'</p>';
				}
				break;					
				case '@M:':
				$EndPos = strpos($Doc, ';')+1;
				$DocI = substr($Doc, 0, $EndPos);
				$M = substr($DocI, 3, strpos($DocI, ';', 3)-3);
				if(isset($F) && $F <> '') {
					$DocIndex[$F]['M'][] = str_replace(array('*', '//'),"<br />",$M);
					$DocIndex[$F]['TextS'][] = '<p class="PartMemo">'.str_replace(array('*', '//'),"<br />",$M).'</p>';
				} else {
					$DocIndex['M'][] = str_replace(array('*', '//'),"<br />",$M);
					$DocIndex['TextS'][] = '<p class="PartMemo">'.str_replace(array('*', '//'),"<br />",$M).'</p>';
				}                    
				break;
				case '@S:':
				$EndPos = strpos($Doc, ';')+1;
				$DocI = substr($Doc, 0, $EndPos);
				$S = substr($DocI, 3, strpos($DocI, ';', 3)-3);
				$S = htmlentities($S);
				$S = str_replace("&lt;br /&gt;","<br />",$S);
				if(isset($F) && $F <> '') {
					$DocIndex[$F]['S'][] = str_replace(array('*', '//'),"<br />",$S);
					$DocIndex[$F]['TextS'][] = '<p class="PartS"><small>Sourcecode</small><br />'.str_replace(array('*', '//'),"<br />",$S).'</p>';
				} else {
					$DocIndex['S'][] = str_replace(array('*', '//'),"<br />",$S);
					$DocIndex['TextS'][] = '<p class="PartS"><small>Sourcecode</small><br />'.str_replace(array('*', '//'),"<br />",$S).'</p>';
				}                    
				break;					
				case '@m:':
				$EndPos = strpos($Doc, ';')+1;
				if($_GET['V'] == 'Expert') {
					$DocI = substr($Doc, 0, $EndPos);
					$m = substr($DocI, 3, strpos($DocI, ';', 3)-3);
					if(isset($F) && $F <> '') {
						$DocIndex[$F]['m'][] = str_replace(array('*', '//'),"<br />",$m);
						$DocIndex[$F]['TextS'][] = '<p class="PartMind">'.str_replace(array('*', '//'),"<br />",$m).'</p>';
					} else {
						$DocIndex['m'][] = str_replace(array('*', '//'),"<br />",$m);
						$DocIndex['TextS'][] = '<p class="PartMind">'.str_replace(array('*', '//'),"<br />",$m).'</p>';
					}                    
				}
				break;
				case '@A:':
				$EndPos = strpos($Doc, ';')+1;
				if($_GET['V'] == 'Expert') {
					$DocI = substr($Doc, 0, $EndPos);
					$A = substr($DocI, 3, strpos($DocI, ';', 3)-3);
					if(isset($F) && $F <> '') {
						$DocIndex[$F]['A'] = $A;
						$DocIndex[$F]['TextS'][] = '<p class="PartA"><small>Autor</small><br />'.str_replace(array('*', '//'),"<br />",$A).'</p>';
					} else {
						$DocIndex['A'] = $A;
						$DocIndex['TextS'][] = '<p class="PartA"><small>Autor</small><br />'.str_replace(array('*', '//'),"<br />",$A).'</p>';
					}                    
				}
				break;
				case '@c:':
				$EndPos = strpos($Doc, ';')+1;
				if($_GET['V'] == 'Expert') {
					$DocI = substr($Doc, 0, $EndPos);
					$c = substr($DocI, 3, strpos($DocI, ';', 3)-3);
					$cTrimCount = strpos($c, ':');
					$cDate = substr($c, 0,$cTrimCount);
					$cMemo = substr($c, $cTrimCount+1);
					if(!isset($F)) { $F=''; }
					$cThis = array('Raw'=>$c,'Date'=>$cDate,'Memo'=>$cMemo,'FilePath'=>$DocIndex['FilePath'],'FileName'=>$DocIndex['FileName'],'Func'=>$F);
					if(isset($F) && $F <> '') {
						$DocIndex[$F]['c'][] = $cThis;
						$DocIndex['Cglobal'][] = str_replace(array('*', '//'),"<br />",$c.'<br /><small>'.$F.'</small>');
					} else {
						$DocIndex['c'][] = $cThis;
						$DocIndex['Cglobal'][] = str_replace(array('*', '//'),"<br />",$c);
					}
				}
				break;					
				case '@D:':
				$EndPos = strpos($Doc, ';')+1;
				$DocI = substr($Doc, 0, $EndPos);
				$D = substr($DocI, 3, strpos($DocI, ';', 3)-3);
				if(isset($F) && $F <> '') {
					$DocIndex[$F]['D'][] = str_replace(array('*', '//'),"<br />",$D);
					$DocIndex[$F]['TextS'][] = '<p class="PartD">'.str_replace(array('*', '//'),"<br />",$D).'</p>';
				} else {
					$DocIndex['D'][] = str_replace(array('*', '//'),"<br />",$D);
					$DocIndex['TextS'][] = '<p class="PartD">'.str_replace(array('*', '//'),"<br />",$D).'</p>';
				}                    
				break;
				case '@I:':
				$EndPos = strpos($Doc, ';')+1;
				if($_GET['V'] == 'Expert') {
					$DocI = substr($Doc, 0, $EndPos);
					$I = substr($DocI, 3, strpos($DocI, ';', 3)-3);
					if(isset($F) && $F <> '') {
						$DocIndex[$F]['I'][] = str_replace(array('*', '//'),"<br />",$I);
						$DocIndex[$F]['TextS'][] = '<p class="PartI"><small>Eingabe</small><br />'.str_replace(array('*', '//'),"<br />",$I).'</p>';
					} else {
						$DocIndex['I'][] = str_replace(array('*', '//'),"<br />",$I);
						$DocIndex['TextS'][] = '<p class="PartI"><small>Eingabe</small><br />'.str_replace(array('*', '//'),"<br />",$I).'</p>';	
					}
				}
				break;
				case '@O:':
				$EndPos = strpos($Doc, ';')+1;
				if($_GET['V'] == 'Expert') {
					$DocI = substr($Doc, 0, $EndPos);
					$O = substr($DocI, 3, strpos($DocI, ';', 3)-3);
					if(isset($F) && $F <> '') {
						$DocIndex[$F]['O'][] = str_replace(array('*', '//'),"<br />",$O);
						$DocIndex[$F]['TextS'][] = '<p class="PartO"><small>Ausgabe</small><br />'.str_replace(array('*', '//'),"<br />",$O).'</p>';
					} else {
						$DocIndex['O'][] = str_replace(array('*', '//'),"<br />",$O);
						$DocIndex['TextS'][] = '<p class="PartO"><small>Ausgabe</small><br />'.str_replace(array('*', '//'),"<br />",$O).'</p>';
					}
				}
				break;
				case '@V:':
				$EndPos = strpos($Doc, ';')+1;
				if($_GET['V'] == 'Expert') {
					$DocI = substr($Doc, 0, $EndPos);
					$V = substr($DocI, 3, strpos($DocI, ';', 3)-3);
					if(isset($F) && $F <> '') {
						$DocIndex[$F]['V'][] = str_replace(array('*', '//'),"<br />",$V);
						$DocIndex[$F]['TextS'][] = '<p class="PartV"><small>Variable</small><br />'.str_replace(array('*', '//'),"<br />",$V).'</p>';
					} else {
						$DocIndex['V'][] = str_replace(array('*', '//'),"<br />",$V);
						$DocIndex['TextS'][] = '<p class="PartV"><small>Variable</small><br />'.str_replace(array('*', '//'),"<br />",$V).'</p>';
					} 
				}
				break;
				case '@R:':
				$EndPos = strpos($Doc, ';')+1;
				if($_GET['V'] == 'Expert') {
					$DocI = substr($Doc, 0, $EndPos);
					$R = substr($DocI, 3, strpos($DocI, ';', 3)-3);
					if(isset($F) && $F <> '') {
						$DocIndex[$F]['R'][] = str_replace(array('*', '//'),"<br />",$R);
						$DocIndex[$F]['TextS'][] = '<p class="PartR"><small>Request</small><br />'.str_replace(array('*', '//'),"<br />",$R).'</p>';
						$DocIndex['Rglobal'][] = str_replace(array('*', '//'),"<br />",$R.'<br /><small>'.$F.'</small>');
					} else {
						$DocIndex['R'][] = str_replace(array('*', '//'),"<br />",$R);
						$DocIndex['TextS'][] = '<p class="PartR"><small>Request</small><br />'.str_replace(array('*', '//'),"<br />",$R).'</p>';
						$DocIndex['Rglobal'][] = str_replace(array('*', '//'),"<br />",$R);
					} 
				}
				break;					
				case '@E:':
				$EndPos = strpos($Doc, ';')+1;
				if($_GET['V'] == 'Expert') {
					$DocI = substr($Doc, 0, $EndPos);
					$E = substr($DocI, 3, strpos($DocI, ';', 3)-3);
					if(isset($F) && $F <> '') {
						$DocIndex[$F]['E'][] = str_replace(array('*', '//'),"<br />",$E);
						$DocIndex[$F]['TextS'][] = '<p class="PartE">'.str_replace(array('*', '//'),"<br />",$E).'</p>';
						$DocIndex['Eglobal'][] = str_replace(array('*', '//'),"<br />",$E.'<br /><small>'.$F.'</small>');
					} else {
						$DocIndex['E'][] = str_replace(array('*', '//'),"<br />",$E);
						$DocIndex['TextS'][] = '<p class="PartE">'.str_replace(array('*', '//'),"<br />",$E).'</p>';
						$DocIndex['Eglobal'][] = str_replace(array('*', '//'),"<br />",$E);
					} 
				}
				break;
				case '@stop;':
					$EndPos = FindNext($Doc,array('@start;'));
				break;
			}
			$Doc = substr($Doc, $EndPos);
			$i++;
		} else {
			$Parse = false;
		}
	}
	return $DocIndex;
	//@start;
}

function ParseTxt ($File) {
	//@F:ParseTxt;
	//@M:Für textbasierte Quelldateien kann diese Funktion verwendet werden. Je nach Dateityp könnte aber der Quelltext vorher noch für den Parser vorbereitet werden, falls er mittels PHP noch transformiert werden müsste.;
	return ParseContent(file_get_contents($File),$File);
}

function FindNext($String,$Sep) {
	//@F:FindNext;
	//@M:Findet das nächste Vorkommen.;
	//@I:String<br />Array mit Suchwörtern;
	//@O:Position (Integer);
	$PosS = array();
	for($i=0;$i<count($Sep);$i++) {
		$PosI = strpos($String,$Sep[$i]);
		if(is_int($PosI)) {
			$PosS[] = $PosI;
		}
	}
	if(count($PosS) > 0 ) {
		return min($PosS);
	} else {
		return false;
	}
}

function ChangeLog($ChangeLogS) {
	//@F:ChangeLog;
	//@M:Erzeugt einen ChangeLog aus einem Array mit Daten;
	//@I:Array<br />[Func]<br />[Memo]<br />[Date];
	//@O:Direktausgaben als table;
	if(count($ChangeLogS) > 0 && $ChangeLogS !== ''){
		$ChangeLogS = ab5_SortArrayByColumn($ChangeLogS, 'Date', $Dir = 'SORT_DESC');
		$CurrentDate = '';
		$Return ='<p><table class="ChLog">';
		foreach($ChangeLogS as $ThisLog) {
			if(isset($ThisLog['Func']) && $ThisLog['Func'] !== '') {
				$FuncLink = ''.$ThisLog['Func'].' <a href="#" class="RefLink" onclick="ShowFile(\'Function_'.$GLOBALS['FunctionRef'][$ThisLog['Func']].'\'); return false;">[+]</a>';
			} else {
				$FuncLink = '';
			}
			if($GLOBALS['MultiLang']) {
				if(substr($ThisLog['Memo'],-4) == '::'.$GLOBALS['LangCurrentCode']) {
					$ThisLog['Memo'] = substr($ThisLog['Memo'],0,-4);
					if($CurrentDate == $ThisLog['Date']) {
						$Return = $Return.'<tr><td></td><td>'.$ThisLog['Memo'].'<br /><span class="Sub"><small>'.$FuncLink.'</td></tr>';
					} else {
						$Return = $Return.'<tr><td>'.$ThisLog['Date'].'</td><td>'.$ThisLog['Memo'].'<br /><span class="Sub"><small>'.$FuncLink.'</td></tr>';
					}
					$CurrentDate = $ThisLog['Date'];
				}
			} else {	
				if($CurrentDate == $ThisLog['Date']) {
					$Return = $Return.'<tr><td></td><td>'.$ThisLog['Memo'].'<br /><span class="Sub"><small>'.$FuncLink.'</td></tr>';
				} else {
					$Return = $Return.'<tr><td>'.$ThisLog['Date'].'</td><td>'.$ThisLog['Memo'].'<br /><span class="Sub"><small>'.$FuncLink.'</td></tr>';
				}
				$CurrentDate = $ThisLog['Date'];
			}
		}
		$Return =$Return.'</table></p>';
		return $Return;
	}
}
function GlobalChangeLog($ChangeLogS) {
	//@F:GlobalChangeLog;
	if(count($ChangeLogS) > 0 && $ChangeLogS !== ''){
		$ChangeLogS = ab5_SortArrayByColumn($ChangeLogS, 'Date', $Dir = 'SORT_DESC');
		$CurrentDate = '0000-00-00';
		$Return ='<p><table class="ChLog">';
		foreach($ChangeLogS as $ThisLog) {
			if($GLOBALS['MultiLang']) {
				if(isset($ThisLog['Func']) && $ThisLog['Func'] !== '') {
					$FuncLink = ' > '.$ThisLog['Func'].' <a href="#" class="RefLink" onclick="ShowFile(\'Function_'.$GLOBALS['FunctionRef'][$ThisLog['Func']].'\'); return false;">[+]</a>';
				} else {
					$FuncLink = '';
				}
				if(substr($ThisLog['Memo'],-4) == '::'.$GLOBALS['LangCurrentCode']) {
					$ThisLog['Memo'] = substr($ThisLog['Memo'],0,-4);
					if($CurrentDate == $ThisLog['Date']) {
						$Return = $Return.'<tr><td></td><td>'.$ThisLog['Memo'].'<br /><span class="Sub"><small>'.$ThisLog['FileName'].' <a href="#" class="RefLink" onclick="ShowFile(\'File_'.$GLOBALS['FileRef'][$ThisLog['FilePath']].'\'); return false;">[+]</a> '.$FuncLink.'</small></span></td></tr>';
					} else {
						$Return = $Return.'<tr><td>'.$ThisLog['Date'].'</td><td>'.$ThisLog['Memo'].'<br /><span class="Sub"><small>'.$ThisLog['FileName'].' <a href="#" class="RefLink" onclick="ShowFile(\'File_'.$GLOBALS['FileRef'][$ThisLog['FilePath']].'\'); return false;">[+]</a> '.$FuncLink.'</small></span></td></tr>';
					}
					$CurrentDate = $ThisLog['Date'];
				}
			} else {
				if(isset($ThisLog['Func']) && $ThisLog['Func'] !== '') {
					$FuncLink = ' > '.$ThisLog['Func'].' <a href="#" class="RefLink" onclick="ShowFile(\'Function_'.$GLOBALS['FunctionRef'][$ThisLog['Func']].'\'); return false;">[+]</a>';
				} else {
					$FuncLink = '';
				}
				if($CurrentDate == $ThisLog['Date']) {
					$Return = $Return.'<tr><td></td><td>'.$ThisLog['Memo'].'<br /><span class="Sub"><small>'.$ThisLog['FileName'].' <a href="#" class="RefLink" onclick="ShowFile(\'File_'.$GLOBALS['FileRef'][$ThisLog['FilePath']].'\'); return false;">[+]</a> '.$FuncLink.'</small></span></td></tr>';
				} else {
					$Return = $Return.'<tr><td>'.$ThisLog['Date'].'</td><td>'.$ThisLog['Memo'].'<br /><span class="Sub"><small>'.$ThisLog['FileName'].' <a href="#" class="RefLink" onclick="ShowFile(\'File_'.$GLOBALS['FileRef'][$ThisLog['FilePath']].'\'); return false;">[+]</a> '.$FuncLink.'</small></span></td></tr>';
				}
				$CurrentDate = $ThisLog['Date'];						
			}
		}
		$Return =$Return.'</table></p>';
		return $Return;
	}
}

function ab5_SortArrayByColumn($Arr, $Col, $Dir = 'SORT_ASC') {
	//@F:ab5_SortArrayByColumn;
	if(count($Arr) > 0 && $Arr !== '') {
		foreach ($Arr as $Key => $Row) {
			$SortCol[$Key] = $Row[$Col];
		}
		$Dir = constant($Dir);
		array_multisort($SortCol, $Dir, $Arr);
	}
	return $Arr;
}
function ab5_ReturnArrayAsTree($Array, $Level = '1', $Result = '') {
	//@F:ab5_ReturnArrayAsTree;
	if(count($Array)>0 && $Array !== ''){
		foreach ($Array as $Key => $Value) {
			if (is_array($Value)) {
				$Result = $Result . str_repeat(' | ', $Level) . '+ ' . htmlentities(utf8_decode($Key)) . '<br />';
				$Result = ab5_ReturnArrayAsTree($Value, $Level + 1, $Result);
			} else {
				$Result = $Result . str_repeat(' | ', $Level) . '- ' . htmlentities(utf8_decode($Key)) . ': ' . htmlentities(utf8_decode($Value)) . '<br />';
			}
		}
	}
	return $Result;
}
function RenderLog($LogS,$Group = 'Date',$Dir = 'SORT_DESC') {
	//@F:RenderLog;
	if(count($LogS) > 0 && $LogS !== ''){
		$LogS = ab5_SortArrayByColumn($LogS, $Group, $Dir);		
		$Current[$Group] = '';
		$Return ='<p>';
		//<a href="#" class="RefLink" onclick="ShowFile(\'File_'.$GLOBALS['FileRef'][$ThisLog[$Group]].'\'); return false;">[+]</a>
		foreach($LogS as $ThisLog) {
			if(isset($ThisLog['FilePath']) && $ThisLog['FilePath'] !== '') {
				$RefLink = '<a href="#" class="RefLink" onclick="ShowFile(\'File_'.$GLOBALS['FileRef'][$ThisLog['FilePath']].'\'); return false;">[+]</a>';
			} else {
				$RefLink = '';
			}
			if($Current[$Group] !== $ThisLog[$Group]) {
				$Return = $Return.'<span class="HeadlineCH2">'.$ThisLog[$Group].' '.$RefLink.'</span>';
			}
			$Return = $Return.'<table class="ChLog">';
			if(count($ThisLog['DataS']) > 0 && $ThisLog['DataS'] !== ''){
				foreach ($ThisLog['DataS'] as $Data) {
					if($GLOBALS['MultiLang']) {
						if(substr($Data,-4) == '::'.$GLOBALS['LangCurrentCode']) {
							$Data = substr($Data,0,-4);
							$Return = $Return.'<tr><td>'.$Data.'</td></tr>';
						}
					} else {
						$Return = $Return.'<tr><td>'.$Data.'</td></tr>';
					}
				}			
			}
			$Return = $Return.'</table>';
			$Current[$Group] = $ThisLog[$Group];
		}
		$Return =$Return.'</p>';
		return $Return;
	}
}
?>