<?php
//@E:Still in development! Only for experimental use!;
//@A:Markus Hottenrott @ share2brain.com;

$GLOBALS['AppVersion']['Composer'] = 'v0.0.3 (2015-02-03)';

require_once('lib.php');

//@V:SetCfg < set.config;
$SetCfg = json_decode(file_get_contents('set.config'));

$LangS = explode(',', $SetCfg->DOC_Lang);
//@M:Es werden alle Sprachen geladen, die als verfügbar konfiguriert wurden.;
//@M:Wenn eine Sprache konfigurierte wurde, jedoch keine Sprachdatei hinterlegt ist, wird alternativ englisch verwendet.;
foreach ($LangS as $LangCode) {
	if(is_file($LangCode.'.lang')) {
		$Locale[$LangCode] = json_decode(file_get_contents($LangCode.'.lang'));
	} else {
		$Locale[$LangCode] = json_decode(file_get_contents('en.lang'));
	}
}

//@m:Für besonders umfangreiche Projekte sollte die max_execution_time angepasst werden;
ini_set('max_execution_time', 1440);
date_default_timezone_set($SetCfg->SET_TimeZone);

//@m:ErrorReporting für PHP kann de/aktiviert werden.;
if($SetCfg->SET_ErrorReporting == true) {
	error_reporting(E_ALL);
	ini_set('display_errors', 1);
}

//@m:Festlegung einer Sprache oder setzen der Standardsprache;
//@V:LangCurrent<br />LangCurrentCode;
if(isset($_GET['L'])) { $GLOBALS['LangCurrent'] = $Locale[$_GET['L']]; $GLOBALS['LangCurrentCode'] = $_GET['L']; } else { $GLOBALS['LangCurrent'] = $Locale[$LangS[0]];	$GLOBALS['LangCurrentCode'] = $LangS[0]; }
//@m:Sind mehr als eine Sprache aktiv, wird MultiLang auf true gesetzt;
//@V:MultiLang: true/false;
if(count($LangS) > 1) {	$GLOBALS['MultiLang'] = true; } else { $GLOBALS['MultiLang'] = false; }
//@M:Der Composer setzt MultiDoc voraus und setzt den Wert daher immer auf "true";
$GLOBALS['MultiDoc'] = true;
//@V:$GLOBALS['DocS'] beinhaltet alle Unterpfade von DocS<br />$GLOBALS['MultiDoc']: true/false;
$GLOBALS['DocS'] = ab5_CrawleDir(array('Path'=>'DocS','Mode'=>'dir','Level'=>'1'));
$GLOBALS['DocS'] = $GLOBALS['DocS']['Result'];
$Templ = '<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"/></head><body style="border-width: 0px; padding: 0px; margin: 0px; font-family: Open Sans; background-color: #DDDDDD;">
<div class="wrapper" style="position: relative; width: 90%; max-width: 1200px; margin-left: auto; margin-right: auto;">
	<div class="left1" style="position: relative; float: left; left: 0px; width: 100px; background-color: #0096ff; height: 100%;">
		<div id="NavBar" style="padding: 5px;">{{NavBar}}</div>
	</div><form style="margin: 0px;" action="#" method="POST">
	<div class="left2" style="position: relative; float: left; left: 0px; width: calc(50% - 51px); background-color: #FFFFFF; border-right: 1px solid #0096ff; height: 100%;">
		<div id="Left" style="padding: 5px;">{{LeftContent}}</div>
	</div>
	<div class="left3" style="position: relative; float: left; left: 0px; width: calc(50% - 50px); background-color: #FFFFFF; height: 100%;">
		<div id="Right" style="padding: 5px;">{{RightContent}}</div>
	</div></form>
</div>
<style>
	#NavBar { overflow-x: hidden; overflow-y: auto; height: calc( 100% - 10px ); }
	#LeftContent { overflow-x: hidden; overflow-y: auto; height: calc( 100% - 10px ); }
	#RightContent { overflow-x: hidden; overflow-y: auto;  height: calc( 100% - 10px ); }
	body{ font-family: Open Sans; font-size: 10pt; }
	#NavBar h1 { color: #FFFFFF; }
	.Headline { display:block; font-variant: small-caps; color: #0096ff; font-size: 20pt; font-weight: light;} 
	#NavBar .Headline { color: #FFFFFF; }
	h1 { color: #0096ff; font-size: 20pt; font-weight: normal; margin: 5px; }
	h2 { color: #0096ff; font-size: 15pt; font-weight: normal; margin: 5px; }
	h3 { color: #0096ff; font-size: 11pt; font-weight: normal; margin: 5px; }
	p {margin: 5px 10px 5px 10px;}
	.MenuLink { color: #FFFFFF; text-decoration: none; cursor: pointer; }
</style>
<script>function HideByClass(e){var t=document.querySelectorAll("."+e),n=0,r=t.length;for(n;n<r;n++){t[n].style.display="none"}}function ShowByClass(e){var t=document.querySelectorAll("."+e),n=0,r=t.length;for(n;n<r;n++){t[n].style.display="block"}}function ShowById(e){document.getElementById(e).style.display="block"}function HideById(e){document.getElementById(e).style.display="none"}
</script>
</body></html>';
$Templ = str_replace('{{NavBar}}', '<span class="Headline"><a href="/" class="MenuLink">'.$GLOBALS['LangCurrent']->Global->Start.'</a></span><a class="MenuLink" href="?Mode=Add">'.$GLOBALS['LangCurrent']->Composer->Add.'</a><br /><a class="MenuLink" href="?Mode=Remove">'.$GLOBALS['LangCurrent']->Composer->Remove.'</a><br /><br /><a class="MenuLink" href="?Run=all">'.$GLOBALS['LangCurrent']->Composer->Run.'</a>', $Templ);
if(!isset($_GET['Mode'])) { $_GET['Mode'] = 'Add'; }
switch($_GET['Mode']) {
	case 'Add':
		//@H:Modus "Add";
		//@D:In diesem Modus kann man Quelldateien einer Zieldatei zuordnen.;
		$SourceFileS = ab5_CrawleDir(array('Path'=>$SetCfg->PATH_Parts));
		$SourceFileList = '';
		if(count($SourceFileS['Result'])>0) {
			foreach($SourceFileS['Result'] as $SourceFile) {
				$SourceFileRel = substr($SourceFile, strlen($SetCfg->PATH_Parts)+1);
				$SourceFileList .= '<input type="checkbox" name="SourceS['.$SourceFile.']" />'.$SourceFileRel.'<br />';
			}
		}
		$Templ = str_replace('{{LeftContent}}', '<span class="Headline">'.$GLOBALS['LangCurrent']->Composer->Parts.'</span>'.$SourceFileList, $Templ);

		$TargetFileS = ab5_CrawleDir(array('Path'=>$SetCfg->PATH_Sources));
		$TargetFileList = '';
		if(count($TargetFileS['Result'])>0) {
			foreach ($TargetFileS['Result']  as $TargetFile) {
				$TargetFileRel = substr($TargetFile, strlen($SetCfg->PATH_Sources)+1);
				$TargetFileList .= '<button type="submit" value="'.$TargetFile.'" name="Target"/>+</button>'.$TargetFileRel.'<br />';	
			}
		}
		$Templ = str_replace('{{RightContent}}', '<span class="Headline">'.$GLOBALS['LangCurrent']->Composer->Target.'</span>'.$TargetFileList, $Templ);
		break;
	case 'Remove':
		//@H:Modus "Remove";
		//@D:In diesem Modus kann man die Verbindung von einer Quelldatei zu einer Zieldatei aufheben.;
		$TargetFileS = ab5_CrawleDir(array('Path'=>$SetCfg->PATH_Sources));
		$TargetFileList = '';
		if(count($TargetFileS['Result'])>0) {
			foreach ($TargetFileS['Result']  as $TargetFile) {
				$TargetFileRel = substr($TargetFile, strlen($SetCfg->PATH_Sources)+1);
				$TargetFileList .= '<button type="submit" value="'.$TargetFile.'" name="Index"/>></button>'.$TargetFileRel.'<br />';				
			}
		}
		$Templ = str_replace('{{LeftContent}}', '<span class="Headline">'.$GLOBALS['LangCurrent']->Composer->Target.'</span>'.$TargetFileList, $Templ);
		
		if(isset($_POST['RemoveFile'])) {
			$Cfg = json_decode(file_get_contents('my.config'));
			$RemoveFile = explode('|', $_POST['RemoveFile']);
			$SourceFile = str_replace(DIRECTORY_SEPARATOR.DIRECTORY_SEPARATOR,DIRECTORY_SEPARATOR, $RemoveFile[1]);
			$_POST['Index'] = $RemoveFile[0];
			$Target = str_replace(DIRECTORY_SEPARATOR.DIRECTORY_SEPARATOR,DIRECTORY_SEPARATOR, $RemoveFile[0]);
			unset($Cfg->ComposeS->$Target->$SourceFile);
			file_put_contents('my.config', json_encode($Cfg));
		}		

		if(isset($_POST['Index'])) {
			$SourceFileList = '';
			$Cfg = json_decode(file_get_contents('my.config'));
			$_POST['Index2'] = str_replace(DIRECTORY_SEPARATOR.DIRECTORY_SEPARATOR,DIRECTORY_SEPARATOR, $_POST['Index']);
			if(count($Cfg->ComposeS->$_POST['Index2'])>0) {
				foreach($Cfg->ComposeS->$_POST['Index2'] as $SourceFile=>$State) {
					$SourceFileRel = substr($SourceFile, 8);
					if($State == 1) {
						$SourceFileList .= '<button name="RemoveFile" value="'.$_POST['Index2'].'|'.$SourceFile.'" />X</button> '.$SourceFileRel.'<br />';
					}
				}
			}
			$Templ = str_replace('{{RightContent}}', '<span class="Headline">'.$GLOBALS['LangCurrent']->Composer->Parts.'</span>'.$SourceFileList, $Templ);
		} else {
			$Templ = str_replace('{{RightContent}}', '<span class="Headline">'.$GLOBALS['LangCurrent']->Composer->Parts.'</span>', $Templ);
		}
		break;
	default:
} 
echo $Templ;

if(isset($_POST['Target'])) {
	$Cfg = json_decode(file_get_contents('my.config'));
	$Cfg->update = date('Y-m-d H:i',time());
	$Target = str_replace(DIRECTORY_SEPARATOR.DIRECTORY_SEPARATOR, DIRECTORY_SEPARATOR, $_POST['Target']);
	if(count($_POST['SourceS'])>0) {
		foreach($_POST['SourceS'] as $SourceFile=>$State) {
			$SourceFile = str_replace(DIRECTORY_SEPARATOR.DIRECTORY_SEPARATOR, DIRECTORY_SEPARATOR, $SourceFile);
			$SourceFileRel = substr($SourceFile, strlen($SetCfg->PATH_Sources)+1);
			$Cfg->ComposeS->$Target->$SourceFile = true;
		}
	}
	file_put_contents('my.config', json_encode($Cfg));
}

if(isset($_GET['Run'])) {
	$Cfg = json_decode(file_get_contents('my.config'));
	if($_GET['Run'] == 'all') {
		if(count($Cfg->ComposeS)>0) {
			foreach($Cfg->ComposeS as $Target=>$FileS){
				$NewFileContent = '';
				if(count($Cfg->ComposeS->$Target)>0) {
					foreach($Cfg->ComposeS->$Target as $File=>$State) {
						if($State) {
							$FileSource = $File;
							$NewFileContent .= file_get_contents($FileSource);
						}			
					}
				}
				file_put_contents($Target, $NewFileContent);
			}
		}
	} else {
	}
}
?>