<?php
//@E:Still in development! Only for experimental use!;
//@A:Markus Hottenrott @ share2brain.com;

$GLOBALS['AppVersion']['Grabber'] = 'v0.0.4 (2015-02-03)';

require_once('lib.php');

//@V:SetCfg < set.config;
$GLOBALS['SetCfg'] = json_decode(file_get_contents('set.config'));

$LangS = explode(',', $GLOBALS['SetCfg']->DOC_Lang);
//@M:Es werden alle Sprachen geladen, die als verfügbar konfiguriert wurden.;
//@M:Wenn eine Sprache konfigurierte wurde, jedoch keine Sprachdatei hinterlegt ist, wird alternativ englisch verwendet.;
//@M:Man kann Teile des Sprachpakets übersteuern, indem man neben der "de.lang" eine "de.my.lang" Datei anlegt und entsprechende Wert überschreibt. Man könnte zwar auch die ursprüngliche Sprache überschreiben, aber hier wäre dann bei jedem Update Nacharbeit nötig.;
//@c:2015-02-05:Support für Sprachindividualisierung ergänzt;
foreach ($LangS as $LangCode) {
	if(is_file($LangCode.'.lang') and is_file($LangCode.'.my.lang')) {
		$LocaleAll = json_decode(file_get_contents($LangCode.'.lang'));
		$LocaleMy = json_decode(file_get_contents($LangCode.'.my.lang'));		
		$Locale[$LangCode] = (object) array_merge((array) $LocaleAll, (array) $LocaleMy);
	} elseif (is_file($LangCode.'.lang')) {
		$Locale[$LangCode] = json_decode(file_get_contents($LangCode.'.lang'));
	} else {
		$Locale[$LangCode] = json_decode(file_get_contents('en.lang'));
	}
}
//@m:Für besonders umfangreiche Projekte sollte die max_execution_time angepasst werden;
ini_set('max_execution_time', 1440);
date_default_timezone_set($GLOBALS['SetCfg']->SET_TimeZone);

//@m:ErrorReporting für PHP kann de/aktiviert werden.;
if($GLOBALS['SetCfg']->SET_ErrorReporting == true) {
	error_reporting(E_ALL);
	ini_set('display_errors', 1);
}

//@m:Festlegung einer Sprache oder setzen der Standardsprache;
//@V:LangCurrent<br />LangCurrentCode;
if(isset($_GET['L'])) { $GLOBALS['LangCurrent'] = $Locale[$_GET['L']]; $GLOBALS['LangCurrentCode'] = $_GET['L']; } else { $GLOBALS['LangCurrent'] = $Locale[$LangS[0]];	$GLOBALS['LangCurrentCode'] = $LangS[0]; }
//@m:Sind mehr als eine Sprache aktiv, wird MultiLang auf true gesetzt;
//@V:MultiLang: true/false;
if(count($LangS) > 1) {	$GLOBALS['MultiLang'] = true; } else { $GLOBALS['MultiLang'] = false; }
//@M:Der Composer setzt MultiDoc voraus und setzt den Wert daher immer auf "true";
$GLOBALS['MultiDoc'] = true;
//@V:$GLOBALS['DocS'] beinhaltet alle Unterpfade von DocS<br />$GLOBALS['MultiDoc']: true/false;
$GLOBALS['DocS'] = ab5_CrawleDir(array('Path'=>'DocS','Mode'=>'dir','Level'=>'1'));
$GLOBALS['DocS'] = $GLOBALS['DocS']['Result'];
$Templ = '<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"/></head><body style="border-width: 0px; padding: 0px; margin: 0px; font-family: Open Sans; background-color: #DDDDDD;">
<div class="wrapper" style="position: relative; width: 90%; max-width: 1200px; margin-left: auto; margin-right: auto;">
	<div class="left1" style="position: relative; float: left; left: 0px; width: 100px; background-color: #0096ff; height: 100%;">
		<div id="NavBar" style="padding: 5px;">{{NavBar}}</div>
	</div><form style="margin: 0px;" action="#" method="POST">
	<div class="left2" style="position: relative; float: left; left: 0px; width: calc(50% - 51px); background-color: #FFFFFF; border-right: 1px solid #0096ff; height: 100%;">
		<div id="Left" style="padding: 5px;">{{LeftContent}}</div>
	</div>
	<div class="left3" style="position: relative; float: left; left: 0px; width: calc(50% - 50px); background-color: #FFFFFF; height: 100%;">
		<div id="Right" style="padding: 5px;">{{RightContent}}</div>
	</div></form>
</div>
<style>
	#NavBar { overflow-x: hidden; overflow-y: auto; height: calc( 100% - 10px ); }
	#LeftContent { overflow-x: hidden; overflow-y: auto; height: calc( 100% - 10px ); }
	#RightContent { overflow-x: hidden; overflow-y: auto;  height: calc( 100% - 10px ); }
	body{ font-family: Open Sans; font-size: 10pt; }
	#NavBar h1 { color: #FFFFFF; }
	.Headline { display:block; font-variant: small-caps; color: #0096ff; font-size: 20pt; font-weight: light;} 
	#NavBar .Headline { color: #FFFFFF; }
	h1 { color: #0096ff; font-size: 20pt; font-weight: normal; margin: 5px; }
	h2 { color: #0096ff; font-size: 15pt; font-weight: normal; margin: 5px; }
	h3 { color: #0096ff; font-size: 11pt; font-weight: normal; margin: 5px; }
	p {margin: 5px 10px 5px 10px;}
	.MenuLink { color: #FFFFFF; text-decoration: none; cursor: pointer; }
</style>
<script>function HideByClass(e){var t=document.querySelectorAll("."+e),n=0,r=t.length;for(n;n<r;n++){t[n].style.display="none"}}function ShowByClass(e){var t=document.querySelectorAll("."+e),n=0,r=t.length;for(n;n<r;n++){t[n].style.display="block"}}function ShowById(e){document.getElementById(e).style.display="block"}function HideById(e){document.getElementById(e).style.display="none"}
</script>
</body></html>';
$Templ = str_replace('{{NavBar}}', '<span class="Headline"><a href="/" class="MenuLink">'.$GLOBALS['LangCurrent']->Global->Start.'</a></span><a class="MenuLink" href="?Mode=Add">'.$GLOBALS['LangCurrent']->Grabber->Add.'</a><br /><a class="MenuLink" href="?Mode=Remove">'.$GLOBALS['LangCurrent']->Grabber->Remove.'</a><br /><br /><a class="MenuLink" href="?Run=all">'.$GLOBALS['LangCurrent']->Grabber->Run.'</a>', $Templ);
if(!isset($_GET['Mode'])) { $_GET['Mode'] = 'Add'; }
if(isset($_GET['Run'])) { $_GET['Mode'] = 'Run'; }
switch($_GET['Mode']) {
	case 'Add':
		$SourceFileS = ab5_CrawleDir(array('Path'=>$GLOBALS['SetCfg']->PATH_Sources));
		$SourceFileList = '';
		if(count($SourceFileS['Result']) > 0) {
			foreach($SourceFileS['Result'] as $SourceFile) {
				$SourceFileRel = substr($SourceFile, strlen($GLOBALS['SetCfg']->PATH_Sources)+1);
				$SourceFileList .= '<input type="checkbox" name="SourceS['.$SourceFile.']" />'.$SourceFileRel.'<br />';
			}
		}
		$Templ = str_replace('{{LeftContent}}', '<span class="Headline">'.$GLOBALS['LangCurrent']->Grabber->Source.'</span>'.$SourceFileList, $Templ);
		$TargetFileList = '';
		if(count($GLOBALS['DocS']) > 0) {
			foreach ($GLOBALS['DocS']  as $TargetDir) {
				$TargetFileList .= '<h2>'.utf8_encode(substr($TargetDir, strlen($GLOBALS['SetCfg']->PATH_DocS)+1)).'</h2><button type="submit" value="'.$TargetDir.DIRECTORY_SEPARATOR.$GLOBALS['SetCfg']->PATH_DocSet.'" name="Target">'.$GLOBALS['SetCfg']->PATH_DocSet.'</button>'.'<button type="submit" value="'.$TargetDir.DIRECTORY_SEPARATOR.$GLOBALS['SetCfg']->PATH_DocAdd.'" name="Target"/>'.$GLOBALS['SetCfg']->PATH_DocAdd.'</button><br /><br />';	
			}
		}
		$Templ = str_replace('{{RightContent}}', '<span class="Headline">'.$GLOBALS['LangCurrent']->Grabber->Target.'</span>'.$TargetFileList, $Templ);
		break;
	case 'Remove':
		$TargetFileList = '';
		if(count($GLOBALS['DocS']) > 0) {
			foreach ($GLOBALS['DocS']  as $TargetDir) {
				$TargetFileList .= utf8_encode($TargetDir).'<br /><button type="submit" value="'.$TargetDir.DIRECTORY_SEPARATOR.$GLOBALS['SetCfg']->PATH_DocSet.'" name="Index">'.$GLOBALS['SetCfg']->PATH_DocSet.'</button>'.'<button type="submit" value="'.$TargetDir.DIRECTORY_SEPARATOR.$GLOBALS['SetCfg']->PATH_DocAdd.'" name="Index"/>'.$GLOBALS['SetCfg']->PATH_DocAdd.'</button><br /><br />';	
			}
		}
		$Templ = str_replace('{{LeftContent}}', '<span class="Headline">'.$GLOBALS['LangCurrent']->Grabber->Target.'</span>'.$TargetFileList, $Templ);
		if(isset($_POST['RemoveFile'])) {
			$Cfg = json_decode(file_get_contents('my.config'));
			$RemoveFile = explode('|', $_POST['RemoveFile']);
			$SourceFile = str_replace(DIRECTORY_SEPARATOR.DIRECTORY_SEPARATOR,DIRECTORY_SEPARATOR, $RemoveFile[1]);
			$_POST['Index'] = $RemoveFile[0];
			$Target = str_replace(DIRECTORY_SEPARATOR.DIRECTORY_SEPARATOR,DIRECTORY_SEPARATOR, $RemoveFile[0]);
			unset($Cfg->CopyS->$Target->$SourceFile);
			file_put_contents('my.config', json_encode($Cfg));
		}		

		if(isset($_POST['Index'])) {
			//$SourceFileS = ab5_CrawleDir(array('Path'=>$_POST['Index']));
			$SourceFileList = '';
			$Cfg = json_decode(file_get_contents('my.config'));
			$_POST['Index2'] = str_replace('\\\\','\\', $_POST['Index']);
			if(count($Cfg->CopyS->$_POST['Index2']) > 0) {
				foreach($Cfg->CopyS->$_POST['Index2'] as $SourceFile=>$State) {
					$SourceFileRel = substr($SourceFile, 8);
					//$SourceFileExt = 'Sources\\'.$SourceFileRel;
					if($State == 1) {
						$SourceFileList .= '<button name="RemoveFile" value="'.$_POST['Index2'].'|'.$SourceFile.'" />X</button> '.$SourceFileRel.'<br />';
					}
				}
			}
			$Templ = str_replace('{{RightContent}}', '<span class="Headline">'.$GLOBALS['LangCurrent']->Grabber->Source.'</span>'.$SourceFileList, $Templ);
		} else {
			$Templ = str_replace('{{RightContent}}', '<span class="Headline">'.$GLOBALS['LangCurrent']->Grabber->Source.'</span>', $Templ);
		}
		break;
	case 'Run':

		break;
	default:
} 

if(isset($_POST['Target'])) {
	$Cfg = json_decode(file_get_contents('my.config'));
	$Cfg->update = date('Y-m-d H:i',time());
	$Target = str_replace(DIRECTORY_SEPARATOR.DIRECTORY_SEPARATOR, DIRECTORY_SEPARATOR, $_POST['Target']);
	if(count($_POST['SourceS']) > 0) {
		foreach($_POST['SourceS'] as $SourceFile=>$State) {
			$SourceFile = str_replace(DIRECTORY_SEPARATOR.DIRECTORY_SEPARATOR, DIRECTORY_SEPARATOR, $SourceFile);
			$SourceFileRel = substr($SourceFile, strlen($GLOBALS['SetCfg']->PATH_Sources)+1);
			$Cfg->CopyS->$Target->$SourceFile = true;
		}
	}
	file_put_contents('my.config', json_encode($Cfg));
}
if(isset($_GET['Run'])) {
	$Cfg = json_decode(file_get_contents('my.config'));
	$RemoveList = $CopyList = '';
	if($_GET['Run'] == 'all') {
		if(count($Cfg->CopyS) > 0) {
			foreach($Cfg->CopyS as $Target=>$FileS){
				if(count($Cfg->CopyS->$Target) > 0) {
					foreach($Cfg->CopyS->$Target as $File=>$State) {
						if($State) {
							$FileSource = $File;
							$FileTarget = $Target.substr($File,strlen($GLOBALS['SetCfg']->PATH_Sources));
							//@c:2015-02-03:Legt automatisch die Unterverzeichnisse an;
							$TargetPath = substr($FileTarget,0,strrpos($FileTarget, DIRECTORY_SEPARATOR) );
							if(!is_dir($TargetPath)) {
								mkdir($TargetPath);
							}
							file_put_contents($FileTarget, file_get_contents($FileSource));
							$CopyList .= '+Copy: '.$FileSource.' >> '.$FileTarget.'<br />';
						} else {
							unlink($FileTarget);
							$RemoveList .= '-Remove: '.$FileTarget.'<br />';
						}
					}
				}
			}
		}
	} else {
	}
	$Templ = str_replace('{{RightContent}}', '<span class="Headline">'.$GLOBALS['LangCurrent']->Grabber->RemoveS.'</span>'.$RemoveList, $Templ);
	$Templ = str_replace('{{LeftContent}}', '<span class="Headline">'.$GLOBALS['LangCurrent']->Grabber->CopyS.'</span>'.$CopyList, $Templ);
}
echo $Templ;
?>